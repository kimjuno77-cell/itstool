import tkinter as tk
from tkinter import filedialog, messagebox
import win32com.client
import os
import shutil
import time

class PPTMergerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PPT 통합 프로그램 (페이지 순서/서식 완벽 보장)")
        self.root.geometry("450x400")
        self.root.configure(bg="#f5f6f8")
        
        self.file_list = []

        title_font = ("Malgun Gothic", 12, "bold")
        btn_font = ("Malgun Gothic", 10)
        
        instruction_label = tk.Label(root, text="병합할 PPT 파일들을 순서대로 추가하세요.", pady=15, bg="#f5f6f8", font=title_font, fg="#333333")
        instruction_label.pack()

        self.listbox = tk.Listbox(root, selectmode=tk.MULTIPLE, width=55, height=12, font=("Consolas", 9), bd=1, relief=tk.SOLID)
        self.listbox.pack(pady=5, padx=20)

        btn_frame = tk.Frame(root, bg="#f5f6f8")
        btn_frame.pack(pady=15)

        add_btn = tk.Button(btn_frame, text="파일 추가", command=self.add_files, width=12, font=btn_font, bg="#ffffff", relief=tk.GROOVE)
        add_btn.pack(side=tk.LEFT, padx=5)

        clear_btn = tk.Button(btn_frame, text="목록 초기화", command=self.clear_files, width=12, font=btn_font, bg="#ffffff", relief=tk.GROOVE)
        clear_btn.pack(side=tk.LEFT, padx=5)

        merge_btn = tk.Button(root, text="PPT 병합 실행 (순서 및 서식 유지)", command=self.merge_files, bg="#2b579a", fg="white", font=("Malgun Gothic", 11, "bold"), width=30, height=2, relief=tk.RAISED)
        merge_btn.pack(pady=10)

    def add_files(self):
        files = filedialog.askopenfilenames(
            title="PPT 파일 선택",
            filetypes=[("PowerPoint Files", "*.pptx *.ppt")]
        )
        for file in files:
            if file not in self.file_list:
                self.file_list.append(file)
                self.listbox.insert(tk.END, os.path.basename(file))

    def clear_files(self):
        self.file_list.clear()
        self.listbox.delete(0, tk.END)

    def merge_files(self):
        if not self.file_list:
            messagebox.showwarning("경고", "병합할 파일을 먼저 추가해주세요.")
            return
            
        if len(self.file_list) < 2:
            messagebox.showwarning("경고", "최소 2개 이상의 파일을 추가해야 병합이 가능합니다.")
            return

        save_path = filedialog.asksaveasfilename(
            title="저장할 파일 이름 지정",
            defaultextension=".pptx",
            filetypes=[("PowerPoint Files", "*.pptx")]
        )

        if not save_path:
            return

        self.root.config(cursor="wait")
        self.process_merge(save_path)
        self.root.config(cursor="")

    def process_merge(self, save_path):
        ppt_app = None
        merged_ppt = None
        
        try:
            # 1. 첫 번째 파일을 복사하여 기반 문서로 삼기
            first_file = os.path.abspath(self.file_list[0])
            shutil.copyfile(first_file, save_path)
            
            # 파워포인트 제어 객체 생성
            ppt_app = win32com.client.Dispatch("PowerPoint.Application")
            ppt_app.Visible = True 

            # 복사된 병합용 파일 열기
            merged_ppt = ppt_app.Presentations.Open(os.path.abspath(save_path))
            
            # [핵심] 창을 기본 보기 모드로 설정 (1 = ppViewNormal)
            if merged_ppt.Windows.Count > 0:
                merged_ppt.Windows(1).ViewType = 1

            # 2. 두 번째 파일부터 차례대로 슬라이드를 복사하여 맨 뒤에 붙여넣기
            for file in self.file_list[1:]:
                abs_path = os.path.abspath(file)
                source_ppt = ppt_app.Presentations.Open(abs_path)
                
                for i in range(1, source_ppt.Slides.Count + 1):
                    # 소스 슬라이드 복사
                    source_ppt.Slides(i).Copy()
                    
                    # [핵심 오류 수정] 단순히 Select()만 하는 것이 아니라, 화면 시점(View) 자체를 '맨 마지막 슬라이드'로 강제 이동시킴
                    last_index = merged_ppt.Slides.Count
                    if last_index > 0:
                        merged_ppt.Windows(1).View.GotoSlide(last_index)
                    
                    # 창 포커스 맞추기 및 원본 서식 유지 붙여넣기
                    merged_ppt.Windows(1).Activate()
                    ppt_app.CommandBars.ExecuteMso("PasteSourceFormatting")
                    
                    # 클립보드 처리가 끝날 때까지 대기
                    time.sleep(0.5)

                source_ppt.Close()

            merged_ppt.Save()
            messagebox.showinfo("완료", "모든 PPT 파일이 순서대로 완벽하게 병합되었습니다!")

        except Exception as e:
            messagebox.showerror("오류", f"병합 중 오류가 발생했습니다:\n{e}")
            
        finally:
            if merged_ppt:
                try:
                    merged_ppt.Close()
                except: pass

if __name__ == "__main__":
    root = tk.Tk()
    app = PPTMergerApp(root)
    root.mainloop()
