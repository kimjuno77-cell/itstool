@echo off
echo ========================================
echo PPT Merger EXE Builder (Final Order Fix)
echo ========================================
echo.
echo Installing Python Libraries...
python -m pip install pywin32 pyinstaller

echo.
echo Building EXE File...
python -m PyInstaller --noconfirm --onedir --windowed --name "PPT_Merger_Final" "ppt_merger.py"

echo.
echo Build Complete! Please check the 'dist' folder.
pause
